package com.tts.mapsapp.models;

import lombok.Data;

@Data
public class Geometry {
	// private Bounds bounds;
	private Location location;
	private String location_type;
	// private Bounds viewport;	
}
