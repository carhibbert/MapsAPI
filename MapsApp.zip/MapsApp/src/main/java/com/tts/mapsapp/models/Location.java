package com.tts.mapsapp.models;

import lombok.Data;

@Data
public class Location {
	private String city;
	private String state;
	private String lat;
	private String lng;
	
	public String getCity() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getState() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getLat() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setLat(Object lat2) {
		// TODO Auto-generated method stub
		
	}

	public Object getLng() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setLng(Object lng2) {
		// TODO Auto-generated method stub
		
	}
	
}
